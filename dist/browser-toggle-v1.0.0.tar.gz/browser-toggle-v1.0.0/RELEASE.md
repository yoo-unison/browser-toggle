# browser-toggle v1.0.0 发布说明

## 📦 安装

```bash
# 解压
tar -xzf browser-toggle-v1.0.0.tar.gz
cd browser-toggle-v1.0.0

# 安装
bash setup.sh
```

## 🚀 快速开始

```bash
# 启用内置浏览器
openclaw-browser --enable
openclaw gateway restart

# 查看状态
openclaw-browser --status
```

## 📚 文档

- README.md - 项目说明
- INSTALL.md - 安装指南
- 使用指南.md - 详细使用文档

## 📞 支持

- GitHub: https://github.com/openclaw/openclaw
- 文档：https://docs.openclaw.ai

## 📋 变更日志

### v1.0.0 (2026-02-28)
- ✅ 首次发布
- ✅ 一键启用/禁用内置浏览器
- ✅ 自动备份配置
- ✅ 失败自动恢复
- ✅ 支持 Linux/macOS/Windows
